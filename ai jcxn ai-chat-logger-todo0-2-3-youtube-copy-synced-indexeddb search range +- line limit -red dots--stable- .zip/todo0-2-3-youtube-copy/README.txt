AI Chat Logger Explorer update

Base: ai-chat-logger-todo0-2-3-youtube-copy

Changes in this package:
- Retains the existing TODO 0 message folding, TODOs 2-3 search controls, and YouTube-style copy behavior.
- Synchronizes Read more / Show less for the same stable message node ID across the title and datetime panes, updating currently rendered copies without rebuilding either pane.
- Persists each item's expanded/collapsed state in a dedicated IndexedDB database. State is restored after pane switching, sliding-window removal/recreation, Explorer refresh, and browser/extension restarts (provided browser site data is retained).
- Persists the Raw literal checkbox state in the same dedicated IndexedDB database and restores it on Explorer startup.
- During a text-search session, displays a small red dot before each hit onMsg, ask, or ans item in both panes. The dot is outside the folded message text, so it remains visible when the matched line is hidden by folding.
- Clears the hit-dot markers when the search no longer has text hits.

Implementation notes:
- UI preferences use a separate IndexedDB database (`aiChatLoggerExplorerUiState`) so the existing record database schema does not need to change.
- Each expansion entry is stored by stable node ID; the raw-literal checkbox is stored under its own key.

Install by replacing explorer.html and explorer.js with the files in this package. Keep other extension files unchanged.

Validation: JavaScript syntax check passed. Full extension/browser integration should still be tested in the target browser.
