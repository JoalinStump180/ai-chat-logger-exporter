TODO 0 only: long-message folding.

Replace explorer.html and explorer.js in your extension with these files. Keep your existing db.js and other extension files. The top toolbar has m/n line controls (default 3/3); blank is treated as 0. Messages with more than m+n lines show the first m lines, an ellipsis, and last n lines, with an underlined Read more / Show less link under the onMsg#/ask#/ans# label.
