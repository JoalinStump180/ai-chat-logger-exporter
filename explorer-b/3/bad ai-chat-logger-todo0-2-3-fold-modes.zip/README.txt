AI Chat Logger Explorer - folding mode switch

Files:
- explorer.html
- explorer.js

New toolbar control: Fold style
- Current (first + last): preserves the existing shortened-text approach and uses both m and n.
- YouTube CSS clamp: leaves the full message text in the DOM, visually clamps to the first m lines, and ignores n for folding. The existing copy override is bypassed in this mode so native browser selection/copy can be tested, including selections spanning multiple messages.

Note: CSS line-clamping keeps the full text in the DOM, but native clipboard behavior for clipped text can vary by browser. Please test drag-selection and Ctrl+C in the target browser.

Other existing features (including Raw literal search, Fst/Lst/MinL/MaxL, dark-red Read more/Show less, and prior copy behavior in Current mode) are retained.
