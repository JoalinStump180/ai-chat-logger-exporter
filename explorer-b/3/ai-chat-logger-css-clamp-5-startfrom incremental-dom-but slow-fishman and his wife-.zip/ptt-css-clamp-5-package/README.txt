AI Chat Logger — five-line CSS clamp experiment

Base: explorer(8)-incremental-dom.js

What changed:
- PTT message text remains complete in the DOM from initial render.
- CSS -webkit-line-clamp folds the text to five visual lines.
- Adds Read more / Show less below each message when the text overflows.
- Copy handling is selection-aware: when mouse selection starts and ends in PTT message text and includes folded messages, Ctrl+C copies the complete text of folded messages touched by the selection. This handles selections spanning multiple PTT items; it does not require unfolding first.
- Styling is injected by explorer.js, so no HTML/CSS edit is required.

Install:
1. Back up your current explorer.js.
2. Replace it with this package's explorer.js.
3. Keep the existing explorer.html, db.js, background/service worker, and other extension files unchanged.
4. Reload the extension and test both the title/PTT pane and datetime pane.

Validation:
- JavaScript syntax check passed.
- The selection/copy handler was tested in a small Chromium DOM test with CSS-clamped text spanning two messages. Full text from both folded messages was present in clipboard data.
- Full integration inside the extension has not been browser-tested.
