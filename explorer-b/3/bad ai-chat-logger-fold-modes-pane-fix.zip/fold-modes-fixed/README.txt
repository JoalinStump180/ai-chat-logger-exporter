AI Chat Logger Explorer - fold mode switch pane refresh fix

Files:
- explorer.html
- explorer.js

This patch changes only the fold-style dropdown handler. Switching between
Current (first + last) and YouTube CSS clamp now re-renders the existing title
and datetime pane contents without calling seek(), which clears both panes and
rebuilds only the active one.

Keep your existing db.js and other extension files unchanged.
JavaScript syntax checked with node --check. Browser-level behavior should still
be verified in the extension.
