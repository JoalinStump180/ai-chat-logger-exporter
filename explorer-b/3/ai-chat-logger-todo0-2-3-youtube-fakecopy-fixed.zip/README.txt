AI Chat Logger Explorer update

Includes TODO 0 folding, TODO 2 raw literal search, TODO 3 line filters, dark-red Read more / Show less links, and a corrected copy handler that copies the full original text when the selection is inside one folded message.

Replace explorer.html and explorer.js. Keep other extension files unchanged.
