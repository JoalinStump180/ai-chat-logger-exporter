AI Chat Explorer — TODO 2 and TODO 3

Changes:
- Raw literal checkbox: treats the complete search-box value as one case-insensitive literal substring. Quotes and URLID syntax are ordinary text in this mode.
- Fst / Lst: restrict message-text searching to the first N and/or last N lines. If both are set, matching searches the union of those line ranges.
- MinL / MaxL: restrict message-record search matching by the message's line count. Empty fields are ignored.
- Controls trigger a refresh automatically. The existing TODO 0 message-folding controls are retained.

Files:
- explorer-todo2-3.html
- explorer-todo2-3.js

Validation: JavaScript syntax check passed with Node.js. This is not a full browser integration test. Keep the rest of the extension files unchanged.
