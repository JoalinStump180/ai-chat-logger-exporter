AI Chat Logger Explorer update

Changes in this package:
- Retains previous TODO 0 message folding and TODOs 2-3 search controls.
- Changes Read more / Show less link color to dark red.
- When text is selected inside a folded message and copied, the clipboard receives the full original message text.

Install by replacing explorer.html and explorer.js with the files in this package. Keep other extension files unchanged.

Validation: JavaScript syntax check passed. Browser-level selection/copy behavior should still be tested in the target extension/browser.
