AI Chat Logger Explorer update

Base: ai-chat-logger-todo0-2-3-youtube-copy

Changes in this package:
- Retains the existing TODO 0 message folding, TODOs 2-3 search controls, and YouTube-style copy behavior.
- Remembers each message's Read more / Show less state in a runtime-only Set keyed by the message node ID. If the datetime sliding window removes and recreates a node, its expanded/collapsed state is restored. State resets when the Explorer runtime is restarted.
- During a text-search session, displays a small red dot before each hit onMsg, ask, or ans item in both the title pane and datetime pane. The dot is outside the folded message text, so it remains visible when the matched line is hidden by folding.
- Clears the hit-dot markers when the search no longer has text hits.

Install by replacing explorer.html and explorer.js with the files in this package. Keep other extension files unchanged.

Validation: JavaScript syntax check passed. Full extension/browser integration should still be tested in the target browser.
